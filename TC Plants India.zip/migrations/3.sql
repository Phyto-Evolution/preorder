
ALTER TABLE plants ADD COLUMN expires_at DATETIME;
ALTER TABLE plants ADD COLUMN is_archived BOOLEAN DEFAULT 0;
UPDATE plants SET expires_at = datetime(created_at, '+90 days') WHERE expires_at IS NULL;
