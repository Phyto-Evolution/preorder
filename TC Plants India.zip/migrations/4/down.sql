
ALTER TABLE preorders DROP COLUMN plant_size;
ALTER TABLE preorders DROP COLUMN customer_address_line1;
ALTER TABLE preorders DROP COLUMN customer_address_line2;
ALTER TABLE preorders DROP COLUMN customer_city;
ALTER TABLE preorders DROP COLUMN customer_state;
ALTER TABLE preorders DROP COLUMN customer_postal_code;
ALTER TABLE preorders DROP COLUMN customer_country;
