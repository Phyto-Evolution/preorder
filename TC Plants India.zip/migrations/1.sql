
CREATE TABLE plants (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  scientific_name TEXT,
  description TEXT,
  price REAL NOT NULL,
  estimated_availability TEXT,
  image_url TEXT,
  category TEXT,
  difficulty_level TEXT,
  care_instructions TEXT,
  is_available BOOLEAN DEFAULT 1,
  stock_quantity INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
