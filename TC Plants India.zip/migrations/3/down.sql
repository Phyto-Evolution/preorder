
ALTER TABLE plants DROP COLUMN expires_at;
ALTER TABLE plants DROP COLUMN is_archived;
