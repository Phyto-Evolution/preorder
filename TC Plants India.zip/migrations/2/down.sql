
DROP TABLE preorders;
