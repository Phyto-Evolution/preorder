
ALTER TABLE preorders ADD COLUMN tracking_id TEXT;
CREATE TABLE order_tracking (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  preorder_id INTEGER NOT NULL,
  stage TEXT NOT NULL,
  sub_stage TEXT,
  status TEXT DEFAULT 'pending',
  notes TEXT,
  awb_number TEXT,
  completed_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
