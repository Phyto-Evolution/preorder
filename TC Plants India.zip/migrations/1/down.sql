
DROP TABLE plants;
