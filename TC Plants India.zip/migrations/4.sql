
ALTER TABLE preorders ADD COLUMN plant_size TEXT;
ALTER TABLE preorders ADD COLUMN customer_address_line1 TEXT;
ALTER TABLE preorders ADD COLUMN customer_address_line2 TEXT;
ALTER TABLE preorders ADD COLUMN customer_city TEXT;
ALTER TABLE preorders ADD COLUMN customer_state TEXT;
ALTER TABLE preorders ADD COLUMN customer_postal_code TEXT;
ALTER TABLE preorders ADD COLUMN customer_country TEXT DEFAULT 'India';
