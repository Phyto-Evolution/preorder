
DROP TABLE order_tracking;
ALTER TABLE preorders DROP COLUMN tracking_id;
