import { useEffect, useState } from "react";
import { Preorder, Plant } from "@/shared/types";
import ExportButton from "@/react-app/components/ExportButton";
import { Beaker, Users, ShoppingCart, Clock, Plus, Edit3, Trash2, Package } from "lucide-react";

export default function Admin() {
  const [preorders, setPreorders] = useState<(Preorder & { plant_name: string; scientific_name: string | null; price: number })[]>([]);
  const [plants, setPlants] = useState<Plant[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'orders' | 'plants'>('orders');
  const [editingPlant, setEditingPlant] = useState<Plant | null>(null);
  const [isCreatingPlant, setIsCreatingPlant] = useState(false);

  const [plantForm, setPlantForm] = useState({
    name: '',
    scientific_name: '',
    description: '',
    price: 0,
    category: '',
    estimated_availability: '',
    image_url: '',
    difficulty_level: '',
    care_instructions: '',
    stock_quantity: 0,
    expires_at: '',
  });

  useEffect(() => {
    const loadData = async () => {
      try {
        const [preordersRes, plantsRes] = await Promise.all([
          fetch("/api/preorders"),
          fetch("/api/admin/plants")
        ]);
        
        if (preordersRes.ok) {
          const preorderData = await preordersRes.json();
          setPreorders(preorderData);
        }
        
        if (plantsRes.ok) {
          const plantData = await plantsRes.json();
          setPlants(plantData);
        }
      } catch (error) {
        console.error("Failed to load data:", error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  const stats = {
    total: preorders.length,
    pending: preorders.filter(p => p.status === 'pending').length,
    ready: preorders.filter(p => p.status === 'ready').length,
    completed: preorders.filter(p => p.status === 'completed').length,
  };

  const resetForm = () => {
    setPlantForm({
      name: '',
      scientific_name: '',
      description: '',
      price: 0,
      category: '',
      estimated_availability: '',
      image_url: '',
      difficulty_level: '',
      care_instructions: '',
      stock_quantity: 0,
      expires_at: '',
    });
    setEditingPlant(null);
    setIsCreatingPlant(false);
  };

  const handleEditPlant = (plant: Plant) => {
    setEditingPlant(plant);
    setPlantForm({
      name: plant.name,
      scientific_name: plant.scientific_name || '',
      description: plant.description || '',
      price: plant.price,
      category: plant.category || '',
      estimated_availability: plant.estimated_availability || '',
      image_url: plant.image_url || '',
      difficulty_level: plant.difficulty_level || '',
      care_instructions: plant.care_instructions || '',
      stock_quantity: plant.stock_quantity,
      expires_at: plant.expires_at ? plant.expires_at.substring(0, 16) : '',
    });
    setIsCreatingPlant(true);
  };

  const handleSubmitPlant = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const method = editingPlant ? 'PUT' : 'POST';
    const url = editingPlant ? `/api/admin/plants/${editingPlant.id}` : '/api/admin/plants';
    
    const formattedData = {
      ...plantForm,
      scientific_name: plantForm.scientific_name || null,
      description: plantForm.description || null,
      category: plantForm.category || null,
      estimated_availability: plantForm.estimated_availability || null,
      image_url: plantForm.image_url || null,
      difficulty_level: plantForm.difficulty_level || null,
      care_instructions: plantForm.care_instructions || null,
      expires_at: plantForm.expires_at ? new Date(plantForm.expires_at).toISOString() : null,
    };

    try {
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formattedData),
      });

      if (response.ok) {
        // Reload plants
        const plantsRes = await fetch("/api/admin/plants");
        if (plantsRes.ok) {
          const plantData = await plantsRes.json();
          setPlants(plantData);
        }
        resetForm();
      }
    } catch (error) {
      console.error("Failed to save plant:", error);
    }
  };

  const handleDeletePlant = async (id: number) => {
    if (window.confirm('Are you sure you want to delete this plant?')) {
      try {
        const response = await fetch(`/api/admin/plants/${id}`, {
          method: 'DELETE',
        });

        if (response.ok) {
          setPlants(plants.filter(p => p.id !== id));
        }
      } catch (error) {
        console.error("Failed to delete plant:", error);
      }
    }
  };

  const togglePlantAvailability = async (plant: Plant) => {
    try {
      const response = await fetch(`/api/admin/plants/${plant.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...plant,
          is_available: !plant.is_available
        }),
      });

      if (response.ok) {
        setPlants(plants.map(p => 
          p.id === plant.id ? { ...p, is_available: !p.is_available } : p
        ));
      }
    } catch (error) {
      console.error("Failed to update plant availability:", error);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white border border-gray-200 rounded-lg flex items-center justify-center">
                <img src="https://mocha-cdn.com/0198793a-4a60-76d2-8800-1be1db2913d3/tc-plants-logo-detailed.png" alt="TC Plants" className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-black">TC Plants Admin</h1>
                <p className="text-sm text-gray-600">Management Dashboard</p>
              </div>
            </div>
            <ExportButton />
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tab Navigation */}
        <div className="flex gap-4 mb-8">
          <button
            onClick={() => setActiveTab('orders')}
            className={`px-6 py-3 font-semibold rounded-lg transition-colors ${
              activeTab === 'orders' 
                ? 'bg-green-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <ShoppingCart className="w-5 h-5 inline mr-2" />
            Orders
          </button>
          <button
            onClick={() => setActiveTab('plants')}
            className={`px-6 py-3 font-semibold rounded-lg transition-colors ${
              activeTab === 'plants' 
                ? 'bg-green-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <Package className="w-5 h-5 inline mr-2" />
            Plants
          </button>
        </div>

        {activeTab === 'orders' && (
          <>
            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                    <ShoppingCart className="w-6 h-6 text-black" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Total Orders</p>
                    <p className="text-2xl font-bold text-black">{stats.total}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                    <Clock className="w-6 h-6 text-gray-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Pending</p>
                    <p className="text-2xl font-bold text-black">{stats.pending}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                    <Users className="w-6 h-6 text-black" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Ready</p>
                    <p className="text-2xl font-bold text-black">{stats.ready}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                    <Beaker className="w-6 h-6 text-black" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Completed</p>
                    <p className="text-2xl font-bold text-black">{stats.completed}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Preorders Table */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-semibold text-black">Recent Pre-orders</h3>
              </div>
              
              {loading ? (
                <div className="flex justify-center items-center py-12">
                  <div className="animate-spin">
                    <Beaker className="w-8 h-8 text-black" />
                  </div>
                </div>
              ) : preorders.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-gray-500">No pre-orders yet</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Plant</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity & Size</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Value</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {preorders.map((preorder) => (
                        <tr key={preorder.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div>
                              <div className="text-sm font-medium text-black">{preorder.customer_name}</div>
                              <div className="text-sm text-gray-500">{preorder.customer_email}</div>
                              <div className="text-sm text-gray-500">{preorder.customer_phone}</div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div>
                              <div className="text-sm font-medium text-black">{preorder.plant_name}</div>
                              {preorder.scientific_name && (
                                <div className="text-sm italic text-gray-500">{preorder.scientific_name}</div>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-black">
                              <div className="font-medium">{preorder.quantity.toLocaleString()} plants</div>
                              {preorder.plant_size && (
                                <div className="text-xs text-gray-500">{preorder.plant_size} size</div>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-black">
                              ₹{(preorder.price * preorder.quantity).toLocaleString('en-IN')}
                            </div>
                            <div className="text-xs text-gray-500">
                              ₹{preorder.price}/plant
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                              preorder.status === 'pending' ? 'bg-gray-100 text-gray-800' :
                              preorder.status === 'ready' ? 'bg-black text-white' :
                              'bg-gray-100 text-gray-600'
                            }`}>
                              {preorder.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {new Date(preorder.created_at).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </>
        )}

        {activeTab === 'plants' && (
          <>
            {/* Plants Management Header */}
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-bold text-black">Plant Management</h2>
              <button
                onClick={() => setIsCreatingPlant(true)}
                className="inline-flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-medium rounded-lg transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add New Plant
              </button>
            </div>

            {/* Plant Form Modal */}
            {isCreatingPlant && (
              <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
                <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                  <div className="p-6 border-b border-gray-200">
                    <h3 className="text-xl font-bold text-black">
                      {editingPlant ? 'Edit Plant' : 'Add New Plant'}
                    </h3>
                  </div>
                  
                  <form onSubmit={handleSubmitPlant} className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div>
                        <label className="block text-sm font-medium text-black mb-2">Name *</label>
                        <input
                          type="text"
                          required
                          value={plantForm.name}
                          onChange={(e) => setPlantForm({ ...plantForm, name: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-black mb-2">Scientific Name</label>
                        <input
                          type="text"
                          value={plantForm.scientific_name}
                          onChange={(e) => setPlantForm({ ...plantForm, scientific_name: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-black mb-2">Price *</label>
                        <input
                          type="number"
                          step="0.01"
                          required
                          value={plantForm.price}
                          onChange={(e) => setPlantForm({ ...plantForm, price: parseFloat(e.target.value) || 0 })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-black mb-2">Category</label>
                        <input
                          type="text"
                          value={plantForm.category}
                          onChange={(e) => setPlantForm({ ...plantForm, category: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-black mb-2">Stock Quantity</label>
                        <input
                          type="number"
                          value={plantForm.stock_quantity}
                          onChange={(e) => setPlantForm({ ...plantForm, stock_quantity: parseInt(e.target.value) || 0 })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-black mb-2">Estimated Availability</label>
                        <input
                          type="text"
                          value={plantForm.estimated_availability}
                          onChange={(e) => setPlantForm({ ...plantForm, estimated_availability: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                          placeholder="e.g., 2-3 weeks"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-black mb-2">Expires At</label>
                        <input
                          type="datetime-local"
                          value={plantForm.expires_at}
                          onChange={(e) => setPlantForm({ ...plantForm, expires_at: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-black mb-2">Image URL</label>
                        <input
                          type="url"
                          value={plantForm.image_url}
                          onChange={(e) => setPlantForm({ ...plantForm, image_url: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                        />
                      </div>
                    </div>
                    
                    <div className="mb-4">
                      <label className="block text-sm font-medium text-black mb-2">Description</label>
                      <textarea
                        value={plantForm.description}
                        onChange={(e) => setPlantForm({ ...plantForm, description: e.target.value })}
                        rows={3}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                      />
                    </div>
                    
                    <div className="flex gap-4">
                      <button
                        type="submit"
                        className="flex-1 bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors"
                      >
                        {editingPlant ? 'Update Plant' : 'Create Plant'}
                      </button>
                      <button
                        type="button"
                        onClick={resetForm}
                        className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold py-2 px-4 rounded-lg transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

            {/* Plants List */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-semibold text-black">All Plants</h3>
              </div>
              
              {loading ? (
                <div className="flex justify-center items-center py-12">
                  <div className="animate-spin">
                    <Beaker className="w-8 h-8 text-black" />
                  </div>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Plant</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {plants.map((plant) => (
                        <tr key={plant.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div>
                              <div className="text-sm font-medium text-black">{plant.name}</div>
                              {plant.scientific_name && (
                                <div className="text-sm italic text-gray-500">{plant.scientific_name}</div>
                              )}
                              {plant.category && (
                                <div className="text-xs text-gray-500">{plant.category}</div>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-black">${plant.price}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-black">{plant.stock_quantity}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <button
                              onClick={() => togglePlantAvailability(plant)}
                              className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full cursor-pointer ${
                                plant.is_available 
                                  ? 'bg-green-600 text-white' 
                                  : 'bg-gray-100 text-gray-800'
                              }`}
                            >
                              {plant.is_available ? 'Available' : 'Unavailable'}
                            </button>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <div className="flex gap-2">
                              <button
                                onClick={() => handleEditPlant(plant)}
                                className="text-gray-600 hover:text-black"
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDeletePlant(plant.id)}
                                className="text-gray-400 hover:text-red-600"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
