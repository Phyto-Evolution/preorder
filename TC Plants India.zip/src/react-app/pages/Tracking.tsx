import { useState, useEffect } from "react";
import { useSearchParams } from "react-router";
import { Beaker, Package, Truck, CheckCircle, Clock, Search } from "lucide-react";

interface TrackingStage {
  id: number;
  preorder_id: number;
  stage: string;
  sub_stage: string | null;
  status: string;
  notes: string | null;
  awb_number: string | null;
  completed_at: string | null;
  created_at: string;
}

interface PreorderWithTracking {
  id: number;
  tracking_id: string;
  customer_name: string;
  plant_name: string;
  quantity: number;
  plant_size: string;
  created_at: string;
  status: string;
  tracking: TrackingStage[];
}

const STAGES = [
  { key: 'resource_preparation', name: 'Resource Preparation', icon: Beaker },
  { 
    key: 'processing', 
    name: 'Processing Order', 
    icon: Clock,
    subStages: ['Initiation', 'Multiplication', 'Harvesting', 'Rooting', 'Preparing']
  },
  { key: 'packing', name: 'Packing', icon: Package },
  { key: 'shipping', name: 'Shipping', icon: Truck }
];

export default function Tracking() {
  const [searchParams] = useSearchParams();
  const trackingIdFromUrl = searchParams.get('id');
  
  const [trackingId, setTrackingId] = useState(trackingIdFromUrl || '');
  const [orderData, setOrderData] = useState<PreorderWithTracking | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = async (id?: string) => {
    const searchId = id || trackingId;
    if (!searchId.trim()) {
      setError('Please enter a tracking ID');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      const response = await fetch(`/api/tracking/${encodeURIComponent(searchId)}`);
      if (response.status === 404) {
        setError('Order not found. Please check your tracking ID and try again.');
        setOrderData(null);
      } else if (!response.ok) {
        throw new Error('Failed to fetch tracking information');
      } else {
        const data = await response.json();
        setOrderData(data);
      }
    } catch (err) {
      setError('Unable to fetch tracking information. Please try again later.');
      setOrderData(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (trackingIdFromUrl) {
      handleSearch(trackingIdFromUrl);
    }
  }, [trackingIdFromUrl]);

  const getStageStatus = (stageKey: string, subStage?: string) => {
    if (!orderData?.tracking) return 'pending';
    
    const stageTracking = orderData.tracking.filter(t => t.stage === stageKey);
    if (stageTracking.length === 0) return 'pending';
    
    if (subStage) {
      const subStageTracking = stageTracking.find(t => t.sub_stage === subStage);
      return subStageTracking?.status || 'pending';
    }
    
    // For main stages, check if all are completed or if any are in progress
    const allCompleted = stageTracking.every(t => t.status === 'completed');
    const anyInProgress = stageTracking.some(t => t.status === 'in_progress');
    
    if (allCompleted) return 'completed';
    if (anyInProgress) return 'in_progress';
    return 'pending';
  };

  const getAWBNumber = () => {
    if (!orderData?.tracking) return null;
    const shippingStage = orderData.tracking.find(t => t.stage === 'shipping' && t.awb_number);
    return shippingStage?.awb_number || null;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white border border-gray-200 rounded-lg flex items-center justify-center">
                <img src="https://mocha-cdn.com/0198793a-4a60-76d2-8800-1be1db2913d3/tc-plants-logo-detailed.png" alt="TC Plants" className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-black">TC Plants</h1>
                <p className="text-sm text-gray-600">Order Tracking</p>
              </div>
            </div>
            <a
              href="/"
              className="text-black hover:text-gray-700 font-medium transition-colors"
            >
              ← Back to Home
            </a>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Section */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
          <h2 className="text-xl font-semibold text-black mb-4">Track Your Order</h2>
          <div className="flex gap-4">
            <div className="flex-1">
              <input
                type="text"
                value={trackingId}
                onChange={(e) => setTrackingId(e.target.value)}
                placeholder="Enter your tracking ID (e.g., TC-2024-001)"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent"
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              />
            </div>
            <button
              onClick={() => handleSearch()}
              disabled={loading}
              className="px-6 py-3 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white font-semibold rounded-lg transition-all duration-200 flex items-center gap-2"
            >
              {loading ? (
                <Clock className="w-5 h-5 animate-spin" />
              ) : (
                <Search className="w-5 h-5" />
              )}
              {loading ? 'Searching...' : 'Track Order'}
            </button>
          </div>
          {error && (
            <div className="mt-4 bg-gray-100 border border-gray-300 text-gray-800 px-4 py-3 rounded-lg">
              {error}
            </div>
          )}
        </div>

        {orderData && (
          <>
            {/* Order Summary */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
              <h3 className="text-lg font-semibold text-black mb-4">Order Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-600">Tracking ID</p>
                  <p className="font-semibold text-black">{orderData.tracking_id}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Customer</p>
                  <p className="font-semibold text-black">{orderData.customer_name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Plant</p>
                  <p className="font-semibold text-black">{orderData.plant_name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Quantity & Size</p>
                  <p className="font-semibold text-black">
                    {orderData.quantity.toLocaleString()} plants ({orderData.plant_size})
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Order Date</p>
                  <p className="font-semibold text-black">{formatDate(orderData.created_at)}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Status</p>
                  <span className={`inline-flex px-3 py-1 text-sm font-semibold rounded-full ${
                    orderData.status === 'pending' ? 'bg-gray-100 text-gray-800' :
                    orderData.status === 'ready' ? 'bg-green-600 text-white' :
                    orderData.status === 'completed' ? 'bg-green-800 text-white' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {orderData.status.charAt(0).toUpperCase() + orderData.status.slice(1)}
                  </span>
                </div>
              </div>
              
              {getAWBNumber() && (
                <div className="mt-4 p-4 bg-gray-100 border border-gray-200 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Truck className="w-5 h-5 text-black" />
                    <span className="font-semibold text-black">AWB Number: {getAWBNumber()}</span>
                  </div>
                  <p className="text-sm text-gray-700 mt-1">Your order is now shipped. Use this AWB number to track with the courier.</p>
                </div>
              )}
            </div>

            {/* Tracking Timeline */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-black mb-6">Order Progress</h3>
              
              <div className="space-y-8">
                {STAGES.map((stage, index) => {
                  const stageStatus = getStageStatus(stage.key);
                  const Icon = stage.icon;
                  
                  return (
                    <div key={stage.key} className="relative">
                      {index < STAGES.length - 1 && (
                        <div className={`absolute left-6 top-12 w-0.5 h-8 ${
                          stageStatus === 'completed' ? 'bg-green-600' : 'bg-gray-200'
                        }`} />
                      )}
                      
                      <div className="flex items-start gap-4">
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                          stageStatus === 'completed' ? 'bg-green-600 text-white' :
                          stageStatus === 'in_progress' ? 'bg-green-100 text-green-700' :
                          'bg-gray-100 text-gray-400'
                        }`}>
                          {stageStatus === 'completed' ? (
                            <CheckCircle className="w-6 h-6" />
                          ) : (
                            <Icon className="w-6 h-6" />
                          )}
                        </div>
                        
                        <div className="flex-1">
                          <h4 className={`text-lg font-semibold ${
                            stageStatus === 'completed' ? 'text-black' :
                            stageStatus === 'in_progress' ? 'text-black' :
                            'text-gray-500'
                          }`}>
                            {stage.name}
                          </h4>
                          
                          {stage.subStages && (
                            <div className="mt-3 space-y-2">
                              {stage.subStages.map((subStage) => {
                                const subStageStatus = getStageStatus(stage.key, subStage);
                                return (
                                  <div key={subStage} className="flex items-center gap-3 ml-4">
                                    <div className={`w-2 h-2 rounded-full ${
                                      subStageStatus === 'completed' ? 'bg-green-600' :
                                      subStageStatus === 'in_progress' ? 'bg-green-400' :
                                      'bg-gray-300'
                                    }`} />
                                    <span className={`text-sm ${
                                      subStageStatus === 'completed' ? 'text-black' :
                                      subStageStatus === 'in_progress' ? 'text-black' :
                                      'text-gray-500'
                                    }`}>
                                      {subStage}
                                    </span>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                          
                          {/* Show notes for this stage */}
                          {orderData.tracking
                            .filter(t => t.stage === stage.key && t.notes)
                            .map(t => (
                              <div key={t.id} className="mt-2 text-sm text-gray-600 bg-gray-50 rounded-lg p-3">
                                <p>{t.notes}</p>
                                {t.completed_at && (
                                  <p className="text-xs text-gray-500 mt-1">
                                    {formatDate(t.completed_at)}
                                  </p>
                                )}
                              </div>
                            ))}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
