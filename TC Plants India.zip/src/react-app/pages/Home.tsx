import { useEffect, useState } from "react";
import { Plant } from "@/shared/types";
import PlantCard from "@/react-app/components/PlantCard";
import PreOrderModal from "@/react-app/components/PreOrderModal";
import { Beaker, Leaf, Microscope, Sparkles } from "lucide-react";

export default function Home() {
  const [plants, setPlants] = useState<Plant[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPlant, setSelectedPlant] = useState<Plant | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    const loadPlants = async () => {
      try {
        const response = await fetch("/api/plants");
        if (response.ok) {
          const data = await response.json();
          setPlants(data);
        }
      } catch (error) {
        console.error("Failed to load plants:", error);
      } finally {
        setLoading(false);
      }
    };

    loadPlants();
  }, []);

  const handlePreOrder = (plant: Plant) => {
    setSelectedPlant(plant);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedPlant(null);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white border border-gray-200 rounded-lg flex items-center justify-center">
                <img src="https://mocha-cdn.com/0198793a-4a60-76d2-8800-1be1db2913d3/tc-plants-logo-detailed.png" alt="TC Plants" className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-black">TC Plants</h1>
                <p className="text-sm text-gray-600">Specialized Tissue Culture Laboratory</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="mb-8">
            <div className="inline-flex items-center gap-2 bg-green-50 text-green-800 px-4 py-2 rounded-full text-sm font-medium mb-6 border border-green-200">
              <Sparkles className="w-4 h-4 text-green-600" />
              Premium Tissue Culture Plants
            </div>
            <h2 className="text-5xl md:text-6xl font-bold text-black mb-6 leading-tight">
              Rare Genetics,<br />
              <span className="text-gray-700">
                Laboratory Perfected
              </span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              Pre-order carnivorous plants, orchids, exotic tropical fruits, and special genetics propagated through advanced tissue culture. 
              No payment required upfront - we'll contact you when your plants are ready.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <a
                href="/track"
                className="inline-flex items-center gap-2 px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
              >
                Track Your Order
              </a>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto mb-16">
            <div className="text-center">
              <div className="w-16 h-16 bg-green-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Microscope className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-black mb-2">Laboratory Quality</h3>
              <p className="text-gray-600 text-sm">Sterile propagation ensures disease-free, robust plants</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-green-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Leaf className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-black mb-2">Specialized Genetics</h3>
              <p className="text-gray-600 text-sm">Carnivorous plants, orchids, exotic fruits and rare genetics</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-green-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Beaker className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-black mb-2">No Prepayment</h3>
              <p className="text-gray-600 text-sm">Pre-order risk-free, pay only when plants are ready</p>
            </div>
          </div>
        </div>
      </section>

      {/* Plants Grid */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-black mb-4">Available Plants</h3>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Browse our current selection of tissue culture plants. Each plant is carefully propagated 
              in our sterile laboratory environment for optimal health and growth.
            </p>
          </div>

          {loading ? (
            <div className="flex justify-center items-center py-20">
              <div className="animate-spin">
                <Beaker className="w-10 h-10 text-black" />
              </div>
            </div>
          ) : plants.length === 0 ? (
            <div className="text-center py-20">
              <Leaf className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h4 className="text-xl font-semibold text-gray-600 mb-2">No Plants Available</h4>
              <p className="text-gray-500">
                We're currently preparing new plants in our laboratory. Check back soon!
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {plants.map((plant) => (
                <PlantCard
                  key={plant.id}
                  plant={plant}
                  onPreOrder={handlePreOrder}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
              <img src="https://mocha-cdn.com/0198793a-4a60-76d2-8800-1be1db2913d3/tc-plants-logo-detailed.png" alt="TC Plants" className="w-6 h-6" />
            </div>
            <span className="text-xl font-bold">TC Plants India</span>
          </div>
          <p className="text-gray-400 mb-4">
            Specialized tissue culture laboratory for carnivorous plants, orchids, exotic tropical fruits and rare genetics
          </p>
          <p className="text-sm text-gray-500">
            © 2024 TC Plants India. All rights reserved.
          </p>
        </div>
      </footer>

      <PreOrderModal
        plant={selectedPlant}
        isOpen={isModalOpen}
        onClose={handleCloseModal}
      />
    </div>
  );
}
