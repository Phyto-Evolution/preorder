import { useState, useEffect } from "react";
import { Plant, CreatePreorder } from "@/shared/types";
import { X, Loader2, CheckCircle, Plus, Trash2, Download } from "lucide-react";
import jsPDF from "jspdf";

interface PreOrderModalProps {
  plant: Plant | null;
  isOpen: boolean;
  onClose: () => void;
}

interface PlantOrderItem {
  plant: Plant;
  quantity: number;
  plant_size: string;
}

const QUANTITY_OPTIONS = [100, 250, 500, 1000, 2500, 10000];
const SIZE_OPTIONS = ['Small', 'Medium', 'Large'];

export default function PreOrderModal({ plant, isOpen, onClose }: PreOrderModalProps) {
  const [plantItems, setPlantItems] = useState<PlantOrderItem[]>([]);
  const [formData, setFormData] = useState({
    customer_name: "",
    customer_email: "",
    customer_phone: "+91",
    customer_address_line1: "",
    customer_address_line2: "",
    customer_city: "",
    customer_state: "",
    customer_postal_code: "",
    customer_country: "India",
    notes: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState("");
  const [availablePlants, setAvailablePlants] = useState<Plant[]>([]);

  // Load available plants when modal opens
  useEffect(() => {
    if (isOpen && plant) {
      // Initialize with the selected plant
      setPlantItems([{ plant, quantity: 100, plant_size: 'Small' }]);
      
      // Load all available plants
      fetch("/api/plants")
        .then(res => res.json())
        .then(data => setAvailablePlants(data))
        .catch(console.error);
    }
  }, [isOpen, plant]);

  if (!isOpen || !plant) return null;

  const addPlantItem = () => {
    if (availablePlants.length > 0) {
      const newPlant = availablePlants.find(p => !plantItems.some(item => item.plant.id === p.id)) || availablePlants[0];
      setPlantItems([...plantItems, { plant: newPlant, quantity: 100, plant_size: 'Small' }]);
    }
  };

  const removePlantItem = (index: number) => {
    if (plantItems.length > 1) {
      setPlantItems(plantItems.filter((_, i) => i !== index));
    }
  };

  const updatePlantItem = (index: number, field: keyof PlantOrderItem, value: Plant | number | string) => {
    const updated = [...plantItems];
    if (field === 'plant' && typeof value === 'object') {
      updated[index].plant = value as Plant;
    } else if (field === 'quantity' && typeof value === 'number') {
      updated[index].quantity = value;
    } else if (field === 'plant_size' && typeof value === 'string') {
      updated[index].plant_size = value;
    }
    setPlantItems(updated);
  };

  const calculateTotal = () => {
    return plantItems.reduce((total, item) => total + (item.plant.price * item.quantity), 0);
  };

  const generateOrderPDF = () => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.width;
    const margin = 20;
    let yPosition = 20;

    // Organization Header
    doc.setFontSize(18);
    doc.setFont("helvetica", "bold");
    doc.text("TC PLANTS INDIA", margin, yPosition);
    yPosition += 8;

    doc.setFontSize(12);
    doc.setFont("helvetica", "normal");
    doc.text("Phyto Evolution Private Limited", margin, yPosition);
    yPosition += 6;
    doc.text("Forest Studio Labs", margin, yPosition);
    yPosition += 6;
    doc.text("Chennai - 603103", margin, yPosition);
    yPosition += 6;
    doc.text("GST ID: 33AAOCP5431D1ZL", margin, yPosition);
    yPosition += 6;
    doc.text("Phone: +91 82489 84778", margin, yPosition);
    yPosition += 6;
    doc.text("Email: info@tcplants.in", margin, yPosition);
    yPosition += 15;

    // Order Header
    doc.setFontSize(16);
    doc.setFont("helvetica", "bold");
    doc.text("BULK PRE-ORDER CONFIRMATION", margin, yPosition);
    yPosition += 10;

    // Horizontal line
    doc.line(margin, yPosition, pageWidth - margin, yPosition);
    yPosition += 15;

    // Customer Information
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text("CUSTOMER DETAILS:", margin, yPosition);
    yPosition += 8;

    doc.setFont("helvetica", "normal");
    doc.text(`Name: ${formData.customer_name}`, margin, yPosition);
    yPosition += 6;
    doc.text(`Email: ${formData.customer_email}`, margin, yPosition);
    yPosition += 6;
    doc.text(`Phone: ${formData.customer_phone}`, margin, yPosition);
    yPosition += 6;
    
    const address = [
      formData.customer_address_line1,
      formData.customer_address_line2,
      `${formData.customer_city}, ${formData.customer_state} ${formData.customer_postal_code}`,
      formData.customer_country
    ].filter(Boolean).join(", ");
    
    // Split long address into multiple lines if needed
    const addressLines = doc.splitTextToSize(`Address: ${address}`, pageWidth - margin * 2);
    doc.text(addressLines, margin, yPosition);
    yPosition += addressLines.length * 6 + 8;

    if (formData.notes.split(', ').length > 0) {
      doc.text(`Tracking ID(s): ${formData.notes}`, margin, yPosition);
      yPosition += 10;
    }

    // Order Items Header
    doc.setFont("helvetica", "bold");
    doc.text("ORDER ITEMS:", margin, yPosition);
    yPosition += 8;

    // Table Headers
    doc.setFontSize(10);
    const colWidths = [80, 30, 25, 35];
    const startX = margin;
    
    doc.rect(startX, yPosition - 2, colWidths[0] + colWidths[1] + colWidths[2] + colWidths[3], 8);
    doc.text("Plant Name", startX + 2, yPosition + 4);
    doc.text("Qty", startX + colWidths[0] + 2, yPosition + 4);
    doc.text("Size", startX + colWidths[0] + colWidths[1] + 2, yPosition + 4);
    doc.text("Subtotal (₹)", startX + colWidths[0] + colWidths[1] + colWidths[2] + 2, yPosition + 4);
    yPosition += 8;

    // Order Items
    doc.setFont("helvetica", "normal");
    plantItems.forEach((item, index) => {
      const rowY = yPosition + (index * 8);
      doc.text(item.plant.name, startX + 2, rowY + 4);
      doc.text(item.quantity.toLocaleString(), startX + colWidths[0] + 2, rowY + 4);
      doc.text(item.plant_size, startX + colWidths[0] + colWidths[1] + 2, rowY + 4);
      doc.text((item.plant.price * item.quantity).toLocaleString('en-IN'), startX + colWidths[0] + colWidths[1] + colWidths[2] + 2, rowY + 4);
    });
    
    yPosition += plantItems.length * 8 + 10;

    // Total
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.text(`TOTAL ORDER VALUE: ₹${calculateTotal().toLocaleString('en-IN')}`, margin, yPosition);
    yPosition += 15;

    // Footer Information
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.text("IMPORTANT NOTES:", margin, yPosition);
    yPosition += 6;
    doc.text("• This is a bulk pre-order request for tissue culture plants", margin + 5, yPosition);
    yPosition += 5;
    doc.text("• No payment is required at this time", margin + 5, yPosition);
    yPosition += 5;
    doc.text("• We will contact you when your plants are ready for delivery", margin + 5, yPosition);
    yPosition += 5;
    doc.text("• Bulk discounts may apply to final pricing", margin + 5, yPosition);
    yPosition += 5;
    doc.text("• Plants are propagated through advanced tissue culture methods", margin + 5, yPosition);
    yPosition += 10;

    doc.text(`Order Date: ${new Date().toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })}`, margin, yPosition);

    // Save the PDF
    const fileName = `TC-Plants-Order-${formData.notes.split(', ')[0] || 'Confirmation'}.pdf`;
    doc.save(fileName);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError("");

    try {
      const preorderData: CreatePreorder = {
        plants: plantItems.map(item => ({
          plant_id: item.plant.id,
          quantity: item.quantity,
          plant_size: item.plant_size,
        })),
        ...formData,
      };

      const response = await fetch("/api/preorders", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(preorderData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to submit pre-order request");
      }

      const result = await response.json();
      
      // Store tracking IDs for success message
      if (result.tracking_ids && result.tracking_ids.length > 0) {
        setFormData({ ...formData, notes: result.tracking_ids.join(', ') }); // Temporarily store in notes for success display
      }

      setIsSuccess(true);
      setTimeout(() => {
        handleClose();
      }, 5000);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setPlantItems([]);
    setFormData({
      customer_name: "",
      customer_email: "",
      customer_phone: "+91",
      customer_address_line1: "",
      customer_address_line2: "",
      customer_city: "",
      customer_state: "",
      customer_postal_code: "",
      customer_country: "India",
      notes: "",
    });
    setIsSuccess(false);
    setError("");
    onClose();
  };

  if (isSuccess) {
    return (
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
        <div className="bg-white rounded-xl p-8 max-w-md w-full text-center">
          <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-black mb-2">Pre-Order Request Submitted!</h3>
          <p className="text-gray-600 mb-4">
            Thank you for your bulk pre-order request. We'll contact you as soon as your plants are ready for pickup or delivery.
          </p>
          <p className="text-sm font-medium text-black mb-2">
            Total: ₹{calculateTotal().toLocaleString('en-IN')}
          </p>
          {formData.notes && (
            <div className="bg-gray-100 border border-gray-200 rounded-lg p-3 mb-4">
              <p className="text-sm font-semibold text-black mb-1">Your Tracking ID(s):</p>
              <p className="text-sm text-gray-700 font-mono">{formData.notes}</p>
              <a 
                href={`/track?id=${formData.notes.split(', ')[0]}`}
                className="text-xs text-black hover:text-gray-800 underline mt-1 inline-block"
              >
                Track your order →
              </a>
            </div>
          )}
          <div className="flex gap-3 mt-6">
            <button
              onClick={generateOrderPDF}
              className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg transition-colors"
            >
              <Download className="w-4 h-4" />
              Download Order PDF
            </button>
            <button
              onClick={handleClose}
              className="px-4 py-3 bg-gray-100 hover:bg-gray-200 text-black font-medium rounded-lg transition-colors"
            >
              Close
            </button>
          </div>
          <p className="text-sm text-gray-500 mt-3 text-center">This dialog will close automatically in a few seconds...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-black">Bulk Pre-Order Plants</h2>
            <button
              onClick={handleClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Plant Selection */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-black">Plants & Quantities</h3>
                <button
                  type="button"
                  onClick={addPlantItem}
                  className="inline-flex items-center gap-2 px-3 py-2 bg-gray-100 hover:bg-gray-200 text-black rounded-lg transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  Add Plant
                </button>
              </div>

              {plantItems.map((item, index) => (
                <div key={index} className="border border-gray-200 rounded-xl p-4 mb-4">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                    <div>
                      <label className="block text-sm font-medium text-black mb-2">Plant</label>
                      <select
                        value={item.plant.id}
                        onChange={(e) => {
                          const selectedPlant = availablePlants.find(p => p.id === parseInt(e.target.value));
                          if (selectedPlant) updatePlantItem(index, 'plant', selectedPlant);
                        }}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent"
                      >
                        {availablePlants.map(p => (
                          <option key={p.id} value={p.id}>{p.name}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-black mb-2">Quantity</label>
                      <select
                        value={item.quantity}
                        onChange={(e) => updatePlantItem(index, 'quantity', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                      >
                        {QUANTITY_OPTIONS.map(qty => (
                          <option key={qty} value={qty}>{qty.toLocaleString()} plants</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-black mb-2">Size</label>
                      <select
                        value={item.plant_size}
                        onChange={(e) => updatePlantItem(index, 'plant_size', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                      >
                        {SIZE_OPTIONS.map(size => (
                          <option key={size} value={size}>{size}</option>
                        ))}
                      </select>
                    </div>

                    <div className="flex items-end">
                      <div className="text-center">
                        <p className="text-sm text-gray-600 mb-2">Subtotal</p>
                        <p className="text-lg font-bold text-black">
                          ₹{(item.plant.price * item.quantity).toLocaleString('en-IN')}
                        </p>
                        {plantItems.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removePlantItem(index)}
                            className="mt-2 p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              <div className="bg-gray-100 border border-gray-200 rounded-xl p-4">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-semibold text-black">Total Order Value:</span>
                  <span className="text-2xl font-bold text-black">
                    ₹{calculateTotal().toLocaleString('en-IN')}
                  </span>
                </div>
              </div>
            </div>

            {/* Customer Information */}
            <div>
              <h3 className="text-lg font-semibold text-black mb-4">Customer Information</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-black mb-2">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.customer_name}
                    onChange={(e) => setFormData({ ...formData, customer_name: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent"
                    placeholder="Your full name"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-black mb-2">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={formData.customer_email}
                    onChange={(e) => setFormData({ ...formData, customer_email: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                    placeholder="your@email.com"
                  />
                </div>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-black mb-2">Phone Number *</label>
                <input
                  type="tel"
                  required
                  value={formData.customer_phone}
                  onChange={(e) => setFormData({ ...formData, customer_phone: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  placeholder="+91 98765 43210"
                />
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-black mb-2">Address Line 1 *</label>
                <input
                  type="text"
                  required
                  value={formData.customer_address_line1}
                  onChange={(e) => setFormData({ ...formData, customer_address_line1: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  placeholder="House/Flat No., Building Name, Street"
                />
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-black mb-2">Address Line 2</label>
                <input
                  type="text"
                  value={formData.customer_address_line2}
                  onChange={(e) => setFormData({ ...formData, customer_address_line2: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  placeholder="Landmark, Area"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-black mb-2">City *</label>
                  <input
                    type="text"
                    required
                    value={formData.customer_city}
                    onChange={(e) => setFormData({ ...formData, customer_city: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                    placeholder="City"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-black mb-2">State *</label>
                  <input
                    type="text"
                    required
                    value={formData.customer_state}
                    onChange={(e) => setFormData({ ...formData, customer_state: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                    placeholder="State"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-black mb-2">Postal Code *</label>
                  <input
                    type="text"
                    required
                    value={formData.customer_postal_code}
                    onChange={(e) => setFormData({ ...formData, customer_postal_code: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                    placeholder="400001"
                  />
                </div>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-black mb-2">Special Notes</label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent resize-none"
                  placeholder="Any special requests or notes for bulk delivery..."
                />
              </div>
            </div>

            {error && (
              <div className="bg-gray-100 border border-gray-300 text-gray-800 px-4 py-3 rounded-lg">
                {error}
              </div>
            )}

            <div className="bg-gray-100 border border-gray-200 text-gray-700 px-4 py-3 rounded-lg">
              <p className="text-sm">
                <strong>No payment required:</strong> This is a bulk pre-order request for tissue culture plants. We'll contact you when your plants are ready and arrange payment and delivery at that time. Bulk discounts may apply.
              </p>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Submitting Bulk Pre-Order Request...
                </>
              ) : (
                `Submit Bulk Pre-Order Request - ₹${calculateTotal().toLocaleString('en-IN')}`
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
