import { Plant } from "@/shared/types";
import { Beaker, Clock, Leaf } from "lucide-react";
import CountdownTimer from "./CountdownTimer";

interface PlantCardProps {
  plant: Plant;
  onPreOrder: (plant: Plant) => void;
}

export default function PlantCard({ plant, onPreOrder }: PlantCardProps) {
  return (
    <div className="group relative bg-white rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden border border-gray-200">
      <div className="aspect-square bg-gray-100 relative overflow-hidden">
        {plant.image_url ? (
          <img
            src={plant.image_url}
            alt={plant.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Leaf className="w-16 h-16 text-gray-400" />
          </div>
        )}
        <div className="absolute top-4 right-4 flex flex-col gap-2">
          <div className="bg-white/95 backdrop-blur-sm rounded-full px-3 py-1 border border-gray-200">
            <span className="text-sm font-semibold text-black">${plant.price}</span>
          </div>
          {plant.expires_at && <CountdownTimer expiresAt={plant.expires_at} />}
        </div>
      </div>
      
      <div className="p-6">
        <div className="mb-3">
          <h3 className="text-xl font-bold text-black mb-1">{plant.name}</h3>
          {plant.scientific_name && (
            <p className="text-sm italic text-gray-600">{plant.scientific_name}</p>
          )}
        </div>
        
        {plant.description && (
          <p className="text-gray-700 text-sm mb-4 line-clamp-3">{plant.description}</p>
        )}
        
        <div className="flex items-center gap-4 mb-4 text-xs text-gray-600">
          {plant.category && (
            <div className="flex items-center gap-1">
              <Beaker className="w-3 h-3" />
              <span>{plant.category}</span>
            </div>
          )}
          {plant.estimated_availability && (
            <div className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              <span>{plant.estimated_availability}</span>
            </div>
          )}
        </div>
        
        <button
          onClick={() => onPreOrder(plant)}
          className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
        >
          Pre-Order Now
        </button>
        
        <p className="text-xs text-gray-500 text-center mt-2">
          No payment required • We'll contact you when ready
        </p>
      </div>
    </div>
  );
}
