import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { CreatePreorderSchema } from "@/shared/types";
import { z } from "zod";

const app = new Hono<{ Bindings: Env }>();

// Plant schema for admin operations
const PlantCreateSchema = z.object({
  name: z.string().min(1, "Name is required"),
  scientific_name: z.string().nullable().optional(),
  description: z.string().nullable().optional(),
  price: z.number().min(0, "Price must be positive"),
  estimated_availability: z.string().nullable().optional(),
  image_url: z.string().nullable().optional(),
  category: z.string().nullable().optional(),
  difficulty_level: z.string().nullable().optional(),
  care_instructions: z.string().nullable().optional(),
  stock_quantity: z.number().min(0, "Stock quantity must be non-negative").default(0),
  expires_at: z.string().nullable().optional(),
});

// Get all plants (excluding expired ones and auto-archive expired plants)
app.get("/api/plants", async (c) => {
  const db = c.env.DB;
  
  // Archive expired plants
  await db.prepare(`
    UPDATE plants 
    SET is_archived = 1, is_available = 0 
    WHERE expires_at IS NOT NULL 
    AND datetime(expires_at) < datetime('now') 
    AND is_archived = 0
  `).run();
  
  // Get available, non-archived plants
  const plants = await db.prepare(`
    SELECT * FROM plants 
    WHERE is_available = 1 
    AND is_archived = 0 
    ORDER BY name
  `).all();
  
  return c.json(plants.results);
});

// Get single plant
app.get("/api/plants/:id", async (c) => {
  const db = c.env.DB;
  const id = c.req.param("id");
  const plant = await db.prepare(`
    SELECT * FROM plants 
    WHERE id = ? 
    AND is_archived = 0
  `).bind(id).first();
  
  if (!plant) {
    return c.json({ error: "Plant not found" }, 404);
  }
  
  return c.json(plant);
});

// Admin: Get all plants (including archived)
app.get("/api/admin/plants", async (c) => {
  const db = c.env.DB;
  
  const plants = await db.prepare(`
    SELECT * FROM plants 
    ORDER BY created_at DESC
  `).all();
  
  return c.json(plants.results);
});

// Admin: Create new plant
app.post("/api/admin/plants", zValidator("json", PlantCreateSchema), async (c) => {
  const db = c.env.DB;
  const data = c.req.valid("json");
  
  const result = await db.prepare(`
    INSERT INTO plants (
      name, scientific_name, description, price, estimated_availability,
      image_url, category, difficulty_level, care_instructions, stock_quantity, expires_at
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    data.name,
    data.scientific_name || null,
    data.description || null,
    data.price,
    data.estimated_availability || null,
    data.image_url || null,
    data.category || null,
    data.difficulty_level || null,
    data.care_instructions || null,
    data.stock_quantity,
    data.expires_at || null
  ).run();
  
  return c.json({ success: true, id: result.meta.last_row_id });
});

// Admin: Update plant
app.put("/api/admin/plants/:id", zValidator("json", PlantCreateSchema.extend({
  is_available: z.boolean().optional(),
  is_archived: z.boolean().optional(),
})), async (c) => {
  const db = c.env.DB;
  const id = c.req.param("id");
  const data = c.req.valid("json");
  
  await db.prepare(`
    UPDATE plants 
    SET name = ?, scientific_name = ?, description = ?, price = ?, 
        estimated_availability = ?, image_url = ?, category = ?, 
        difficulty_level = ?, care_instructions = ?, stock_quantity = ?, 
        expires_at = ?, is_available = COALESCE(?, is_available),
        is_archived = COALESCE(?, is_archived), updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).bind(
    data.name,
    data.scientific_name || null,
    data.description || null,
    data.price,
    data.estimated_availability || null,
    data.image_url || null,
    data.category || null,
    data.difficulty_level || null,
    data.care_instructions || null,
    data.stock_quantity,
    data.expires_at || null,
    data.is_available,
    data.is_archived,
    id
  ).run();
  
  return c.json({ success: true });
});

// Admin: Delete plant (soft delete by archiving)
app.delete("/api/admin/plants/:id", async (c) => {
  const db = c.env.DB;
  const id = c.req.param("id");
  
  await db.prepare(`
    UPDATE plants 
    SET is_archived = 1, is_available = 0, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).bind(id).run();
  
  return c.json({ success: true });
});

// Create preorder
app.post("/api/preorders", zValidator("json", CreatePreorderSchema), async (c) => {
  const db = c.env.DB;
  const data = c.req.valid("json");
  
  // Validate all plants exist and are available
  for (const plantOrder of data.plants) {
    const plant = await db.prepare(`
      SELECT * FROM plants 
      WHERE id = ? 
      AND is_available = 1 
      AND is_archived = 0
    `).bind(plantOrder.plant_id).first();
    
    if (!plant) {
      return c.json({ error: `Plant with ID ${plantOrder.plant_id} not found or unavailable` }, 400);
    }
    
    // Check if plant has expired
    if (plant.expires_at && new Date(plant.expires_at as string) < new Date()) {
      return c.json({ error: `Plant "${plant.name}" offering has expired` }, 400);
    }
  }
  
  // Create preorders for each plant
  const preorderIds = [];
  for (const plantOrder of data.plants) {
    // Generate tracking ID
    const year = new Date().getFullYear();
    const trackingId = `TC-${year}-${String(Date.now()).slice(-6)}`;
    
    const result = await db.prepare(`
      INSERT INTO preorders (
        plant_id, customer_name, customer_email, customer_phone, quantity, plant_size,
        customer_address_line1, customer_address_line2, customer_city, customer_state,
        customer_postal_code, customer_country, notes, tracking_id
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      plantOrder.plant_id,
      data.customer_name,
      data.customer_email,
      data.customer_phone,
      plantOrder.quantity,
      plantOrder.plant_size,
      data.customer_address_line1,
      data.customer_address_line2 || null,
      data.customer_city,
      data.customer_state,
      data.customer_postal_code,
      data.customer_country,
      data.notes || null,
      trackingId
    ).run();
    
    preorderIds.push(result.meta.last_row_id);
    
    // Initialize tracking stages
    await db.prepare(`
      INSERT INTO order_tracking (preorder_id, stage, status, notes)
      VALUES (?, 'resource_preparation', 'pending', 'Order received and queued for resource preparation')
    `).bind(result.meta.last_row_id).run();
  }
  
  // Get tracking IDs for response
  const trackingIds = [];
  for (const preorderId of preorderIds) {
    const preorder = await db.prepare(`
      SELECT tracking_id FROM preorders WHERE id = ?
    `).bind(preorderId).first();
    if (preorder) trackingIds.push(preorder.tracking_id);
  }
  
  return c.json({ 
    success: true, 
    preorder_ids: preorderIds,
    tracking_ids: trackingIds,
    message: `Bulk pre-order request submitted successfully for ${data.plants.length} plant type(s)! Track your order with ID: ${trackingIds.join(', ')}`
  });
});

// Get preorders (for admin - could be protected later)
app.get("/api/preorders", async (c) => {
  const db = c.env.DB;
  const preorders = await db.prepare(`
    SELECT 
      p.*,
      pl.name as plant_name,
      pl.scientific_name,
      pl.price
    FROM preorders p
    JOIN plants pl ON p.plant_id = pl.id
    ORDER BY p.created_at DESC
  `).all();
  
  return c.json(preorders.results);
});

// Export preorders as CSV
app.get("/api/preorders/export", async (c) => {
  const db = c.env.DB;
  const preorders = await db.prepare(`
    SELECT 
      p.id,
      p.customer_name,
      p.customer_email,
      p.customer_phone,
      p.quantity,
      p.plant_size,
      p.customer_address_line1,
      p.customer_address_line2,
      p.customer_city,
      p.customer_state,
      p.customer_postal_code,
      p.customer_country,
      p.notes,
      p.status,
      p.created_at,
      pl.name as plant_name,
      pl.scientific_name,
      pl.price,
      pl.category
    FROM preorders p
    JOIN plants pl ON p.plant_id = pl.id
    ORDER BY p.created_at DESC
  `).all();
  
  // Create CSV content
  const csvHeader = "Order ID,Customer Name,Email,Phone,Address,City,State,Postal Code,Country,Plant Name,Scientific Name,Category,Size,Price per Unit,Quantity,Total,Status,Notes,Order Date\n";
  const csvRows = preorders.results.map((order: any) => {
    const total = (order.price * order.quantity).toFixed(2);
    const orderDate = new Date(order.created_at).toLocaleDateString();
    const fullAddress = [order.customer_address_line1, order.customer_address_line2].filter(Boolean).join(', ');
    return [
      order.id,
      `"${order.customer_name}"`,
      order.customer_email,
      order.customer_phone || '',
      `"${fullAddress}"`,
      order.customer_city || '',
      order.customer_state || '',
      order.customer_postal_code || '',
      order.customer_country || '',
      `"${order.plant_name}"`,
      `"${order.scientific_name || ''}"`,
      order.category || '',
      order.plant_size || '',
      order.price,
      order.quantity,
      total,
      order.status,
      `"${order.notes || ''}"`,
      orderDate
    ].join(',');
  }).join('\n');
  
  const csvContent = csvHeader + csvRows;
  
  return new Response(csvContent, {
    headers: {
      'Content-Type': 'text/csv',
      'Content-Disposition': `attachment; filename="bulk-preorders-${new Date().toISOString().split('T')[0]}.csv"`
    }
  });
});

// Get tracking information
app.get("/api/tracking/:trackingId", async (c) => {
  const db = c.env.DB;
  const trackingId = c.req.param("trackingId");
  
  // Get preorder with plant information
  const preorder = await db.prepare(`
    SELECT 
      p.*,
      pl.name as plant_name,
      pl.scientific_name,
      pl.price
    FROM preorders p
    JOIN plants pl ON p.plant_id = pl.id
    WHERE p.tracking_id = ?
  `).bind(trackingId).first();
  
  if (!preorder) {
    return c.json({ error: "Order not found" }, 404);
  }
  
  // Get tracking stages
  const tracking = await db.prepare(`
    SELECT * FROM order_tracking 
    WHERE preorder_id = ?
    ORDER BY created_at ASC
  `).bind(preorder.id).all();
  
  return c.json({
    ...preorder,
    tracking: tracking.results
  });
});

export default app;
