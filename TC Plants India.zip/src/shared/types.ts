import z from "zod";

export const PlantSchema = z.object({
  id: z.number(),
  name: z.string(),
  scientific_name: z.string().nullable(),
  description: z.string().nullable(),
  price: z.number(),
  estimated_availability: z.string().nullable(),
  image_url: z.string().nullable(),
  category: z.string().nullable(),
  difficulty_level: z.string().nullable(),
  care_instructions: z.string().nullable(),
  is_available: z.boolean(),
  stock_quantity: z.number(),
  expires_at: z.string().nullable(),
  is_archived: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const PreorderSchema = z.object({
  id: z.number(),
  plant_id: z.number(),
  customer_name: z.string(),
  customer_email: z.string(),
  customer_phone: z.string().nullable(),
  quantity: z.number(),
  plant_size: z.string().nullable(),
  customer_address_line1: z.string().nullable(),
  customer_address_line2: z.string().nullable(),
  customer_city: z.string().nullable(),
  customer_state: z.string().nullable(),
  customer_postal_code: z.string().nullable(),
  customer_country: z.string().nullable(),
  notes: z.string().nullable(),
  status: z.string(),
  estimated_ready_date: z.string().nullable(),
  tracking_id: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const OrderTrackingSchema = z.object({
  id: z.number(),
  preorder_id: z.number(),
  stage: z.string(),
  sub_stage: z.string().nullable(),
  status: z.string(),
  notes: z.string().nullable(),
  awb_number: z.string().nullable(),
  completed_at: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreatePreorderSchema = z.object({
  plants: z.array(z.object({
    plant_id: z.number(),
    quantity: z.number().min(100, "Minimum quantity is 100"),
    plant_size: z.string().min(1, "Size is required"),
  })).min(1, "At least one plant is required"),
  customer_name: z.string().min(1, "Name is required"),
  customer_email: z.string().email("Valid email is required"),
  customer_phone: z.string().min(1, "Phone number is required"),
  customer_address_line1: z.string().min(1, "Address line 1 is required"),
  customer_address_line2: z.string().optional(),
  customer_city: z.string().min(1, "City is required"),
  customer_state: z.string().min(1, "State is required"),
  customer_postal_code: z.string().min(1, "Postal code is required"),
  customer_country: z.string().default("India"),
  notes: z.string().optional(),
});

export type Plant = z.infer<typeof PlantSchema>;
export type Preorder = z.infer<typeof PreorderSchema>;
export type CreatePreorder = z.infer<typeof CreatePreorderSchema>;
export type OrderTracking = z.infer<typeof OrderTrackingSchema>;
